<?php
$db =mysql_select_db('sln',$koneksi);
if(!$db ){die('Gagal'.mysql_error());
}
?>