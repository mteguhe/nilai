<?php
mysql_close($koneksi);
?>