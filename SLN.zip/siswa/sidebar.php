<!-- Begin Wrapper -->
<div id="wrapper">
	<!-- Begin Sidebar -->
	<div id="sidebar">
		 <div id="logo"><a href="index.php"><img src="../style/images/logo1.png" alt="Caprice" width="200" height="80"/></a></div>
		 
	<!-- Begin Menu -->
    <div id="menu" class="menu-v">
      <ul>
        <li><a href="index.html" class="active">Home</a>
        	<ul>
        		<li><a href="index.html">Home w/ Carousel</a></li>
        		<li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        		<li><a href="index3.html">Home w/ Testimonials</a></li>
        	</ul>
        </li>
        <li><a href="nilai_semester.php">Nilai</a></li>
        <li><a href="daftar_kelas.php">Raport</a>
        <li><a href="logout.php">Log Out</a></li>
      </ul>
    </div>
    <!-- End Menu -->
   
    
    <div class="sidebox">
    <ul class="share">
    	<li><a href="#"><img src="../style/images/icon-rss.png" alt="RSS" /></a></li>
    	<li><a href="#"><img src="../style/images/icon-facebook.png" alt="Facebook" /></a></li>
    	<li><a href="#"><img src="../style/images/icon-twitter.png" alt="Twitter" /></a></li>
    	<li><a href="#"><img src="../style/images/icon-dribbble.png" alt="Dribbble" /></a></li>
    	<li><a href="#"><img src="../style/images/icon-linkedin.png" alt="LinkedIn" /></a></li>
    </ul>
    </div>

    
	</div>
	<!-- End Sidebar -->