  
    
    <!-- Begin Footer -->
    <div id="footer">
  	<div class="footer-box one-third">
  	<h3>Popular Posts</h3>
			<ul class="popular-posts">
				<li>
					<a href="#"><img src="../style/images/art/s1.jpg" alt="" /></a>
					<h5><a href="#">Dolor Commodo Consectetur</a></h5>
					<span>26 Aug 2011 | <a href="#">21 Comments</a></span>
				</li>
				
                <li>
					<a href="#"><img src="../style/images/art/s1.jpg" alt="" /></a>
					<h5><a href="#">Dolor Commodo Consectetur</a></h5>
					<span>26 Aug 2011 | <a href="#">21 Comments</a></span>
				</li>


			</ul>
  	</div>
  	<div class="footer-box one-third">
  	<h3>About</h3>
  	<p>   SMA CINTA KASIH TZU CHI<br />
    	  JAKARTA BARAT
          <br>
          <br />
          <span class="lite1">Fax:</span> +555 797 534 01<br>
          <span class="lite1">Tel:</span> +555 636 646 62<br>
          <span class="lite1">E-mail:</span> name@domain.com</p>
          
          
  	</div>
  	
  	<div class="footer-box one-third last">
  	<h3>Custom Text</h3>
  	<p>Donec ullamcorper nulla non metus auctor fringilla. Maecenas faucibus mollis interdum. Curabitur blandit tempus porttitor.</p>
  	</div>
    </div>
    <!-- End Footer -->
    
    
	</div>
	<!-- End Content -->
	
</div>
<!-- End Wrapper -->
<div class="clear"></div>
<script type="text/javascript" src="../style/js/scripts.js"></script>
<!--[if !IE]> -->
<script type="text/javascript" src="../style/js/jquery.corner.js"></script>
<!-- <![endif]-->
</body>
</html>