  
    
    <!-- Begin Footer -->
    <div id="footer">
  	<div class="footer-box one-third">
  	<h3>About</h3>
			<p>   SMA CHANDRA KUSUMA<br />
          Jln. Villa Kapuk Mas Selatan V Blok H4 No 01 <br />
          Jakarta Utara - 11720
          <br>
          <br />
          
  	</div>
    
  	<div class="footer-box one-third">
  	<h3>Contact</h3>
  	<p>   
          
          <span class="lite1">Fax:</span> +555 797 534 01<br>
          <span class="lite1">Tel:</span> +555 636 646 62<br>
          <span class="lite1">E-mail:</span> name@domain.com</p>
          
          
  	</div>
  	
  	<div class="footer-box one-third last">
  	<h3></h3>
  	<p><br />
    Templates By freewebsitetemplates.com<br />
    Modified By M Teguh Erianto
    </p>
  	</div>
    </div>
    <!-- End Footer -->
    
    
	</div>
	<!-- End Content -->
	
</div>
<!-- End Wrapper -->
<div class="clear"></div>
<script type="text/javascript" src="../style/js/scripts.js"></script>
<!--[if !IE]> -->
<script type="text/javascript" src="../style/js/jquery.corner.js"></script>
<!-- <![endif]-->
</body>
</html>