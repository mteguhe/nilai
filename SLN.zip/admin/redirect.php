<?php

echo"<meta http-equiv='refresh' content='3;url=tambah_pelajaran.php'>";

?>